
#!/bin/bash

# Determine the directory of this script
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# Set the env vars

export SCRIPTPACK_RUBY_ROOT="${DIR}/RUBY"

export SCRIPTPACK_STDLIB_ROOT="${DIR}/STDLIB"


# Load the main of our entrypoint
. ${SCRIPTPACK_RUBY_ROOT}/main.sh
